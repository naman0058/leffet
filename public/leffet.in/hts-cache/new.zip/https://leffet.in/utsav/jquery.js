<!doctype html>
<html lang="en"  class="default" >

  <head>
    
      
  <meta charset="utf-8">
<meta name="viewport" content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width, height=device-height, target-densitydpi=device-dpi" />

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-211302207-1"></script>

  <meta http-equiv="x-ua-compatible" content="ie=edge">


  <title>404 error</title>
  <meta name="description" content="This page cannot be found">
  <meta name="keywords" content="">
      
          <link rel="alternate" href="https://leffet.in/page-not-found" hreflang="en-us">
      
  
                  <link rel="alternate" href="https://leffet.in/page-not-found" hreflang="en-us">
        




  <meta name="viewport" content="width=device-width, initial-scale=1">



  <link rel="icon" type="image/vnd.microsoft.icon" href="/img/favicon.ico?1635231173">
  <link rel="shortcut icon" type="image/x-icon" href="/img/favicon.ico?1635231173">


  


	
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '317453666552690');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=317453666552690&ev=PageView&noscript=1"
/></noscript>
	

    <link rel="stylesheet" href="https://leffet.in/themes/leo_qos/assets/css/theme.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/modules/blockreassurance/views/css/front.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/modules/ccavenue/views/css/ccavenue.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/themes/leo_qos/modules/leoslideshow/views/css/typo/typo.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/themes/leo_qos/modules/leoslideshow/views/css/iView/iview.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/themes/leo_qos/modules/leoslideshow/views/css/iView/skin_4_responsive/style.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/themes/leo_qos/modules/leoquicklogin/views/css/front.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/modules/leofeature/views/css/jquery.mCustomScrollbar.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/themes/leo_qos/modules/leofeature/views/css/front.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/themes/leo_qos/modules/leoblog/views/css/leoblog.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/modules/facebookpsconnect/views/css/hook.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/modules/facebookpsconnect/views/css/bootstrap-social.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/modules/facebookpsconnect/views/css/font-awesome.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/modules/facebookpsconnect/views/css/connectors.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/modules/arcontactus/views/css/jquery.contactus.min.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/modules/arcontactus/views/css/generated-desktop.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/modules/baproductscarousel/views/css/assets/owl.carousel.min.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/modules/baproductscarousel/views/css/assets/owl.theme.default.min.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/modules/baproductscarousel/views/css/assets/animate.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/modules/baproductscarousel/views/css/baslider.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/modules/g_testimonial/views/css/front/testimonial.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/modules/boninstagramslick/views/css/boninstagramslick.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/modules/boninstagramslick/views/css/slick.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/modules/boninstagramslick/views/css/slick-theme.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/js/jquery/ui/themes/base/minified/jquery-ui.min.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/js/jquery/ui/themes/base/minified/jquery.ui.theme.min.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/js/jquery/plugins/fancybox/jquery.fancybox.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/modules/blockgrouptop/views/css/blockgrouptop.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/themes/leo_qos/modules/leoproductsearch/views/css/leosearch.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/modules/leoproductsearch/views/css/jquery.autocomplete_productsearch.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/themes/leo_qos/assets/css/custom.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/modules/appagebuilder/views/css/animate.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/themes/leo_qos/modules/appagebuilder/views/css/owl.carousel.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/themes/leo_qos/modules/appagebuilder/views/css/owl.theme.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/themes/leo_qos/modules/appagebuilder/views/css/slick-theme.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/themes/leo_qos/modules/appagebuilder/views/css/slick.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/themes/leo_qos/modules/appagebuilder/views/css/ApImageHotspot.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/themes/leo_qos/modules/appagebuilder/views/css/styles.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/modules/appagebuilder/views/css/unique.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/themes/leo_qos/modules/appagebuilder/views/css/positions/headerposition1501866647.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/themes/leo_qos/modules/appagebuilder/views/css/positions/footerposition2878685553.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/themes/leo_qos/modules/appagebuilder/views/css/profiles/profile2148522184.css" type="text/css" media="all">
  <link rel="stylesheet" href="https://leffet.in/themes/leo_qos/modules/appagebuilder/views/css/patterns/profile-1612869183.css" type="text/css" media="all">



    


  

  <script type="text/javascript">
        var BONINSTAGRAMSLICK_DISPLAY_CAROUSEL = "1";
        var BONINSTAGRAMSLICK_DOTS = "0";
        var BONINSTAGRAMSLICK_LOOP = "1";
        var BONINSTAGRAMSLICK_MARGIN = "5000";
        var BONINSTAGRAMSLICK_NAV = "1";
        var BONINSTAGRAMSLICK_NB = "5";
        var LEO_COOKIE_THEME = "LEO_QOS_PANEL_CONFIG";
        var add_cart_error = "An error occurred while processing your request. Please try again";
        var ajaxsearch = "1";
        var buttonwishlist_title_add = "Add to Wishlist";
        var buttonwishlist_title_remove = "Remove from WishList";
        var cancel_rating_txt = "Cancel Rating";
        var disable_review_form_txt = "Not exists a criterion to review for this product or this language";
        var enable_dropdown_defaultcart = 1;
        var enable_flycart_effect = 1;
        var enable_notification = 1;
        var height_cart_item = "135";
        var isLogged = false;
        var leo_push = 0;
        var leo_search_url = "https:\/\/leffet.in\/module\/leoproductsearch\/productsearch";
        var leo_token = "b68a7b36e8930a00073a73a5e6feb04a";
        var leoproductsearch_static_token = "b68a7b36e8930a00073a73a5e6feb04a";
        var leoproductsearch_token = "1e349f1ad001a955c4ebab3a87a0ed6b";
        var lf_is_gen_rtl = false;
        var lps_show_product_img = "1";
        var lps_show_product_price = "1";
        var lql_ajax_url = "https:\/\/leffet.in\/module\/leoquicklogin\/leocustomer";
        var lql_is_gen_rtl = false;
        var lql_module_dir = "\/modules\/leoquicklogin\/";
        var lql_myaccount_url = "https:\/\/leffet.in\/my-account";
        var lql_redirect = "";
        var number_cartitem_display = 3;
        var numpro_display = "100";
        var prestashop = {"cart":{"products":[],"totals":{"total":{"type":"total","label":"Total","amount":0,"value":"\u20b90"},"total_including_tax":{"type":"total","label":"Total (tax incl.)","amount":0,"value":"\u20b90"},"total_excluding_tax":{"type":"total","label":"Total (tax excl.)","amount":0,"value":"\u20b90"}},"subtotals":{"products":{"type":"products","label":"Subtotal","amount":0,"value":"\u20b90"},"discounts":null,"shipping":{"type":"shipping","label":"Shipping","amount":0,"value":"Free"},"tax":null},"products_count":0,"summary_string":"0 items","vouchers":{"allowed":0,"added":[]},"discounts":[],"minimalPurchase":0,"minimalPurchaseRequired":""},"currency":{"name":"Indian Rupee","iso_code":"INR","iso_code_num":"356","sign":"\u20b9"},"customer":{"lastname":null,"firstname":null,"email":null,"birthday":null,"newsletter":null,"newsletter_date_add":null,"optin":null,"website":null,"company":null,"siret":null,"ape":null,"is_logged":false,"gender":{"type":null,"name":null},"addresses":[]},"language":{"name":"English (English)","iso_code":"en","locale":"en-US","language_code":"en-us","is_rtl":"0","date_format_lite":"m\/d\/Y","date_format_full":"m\/d\/Y H:i:s","id":1},"page":{"title":"The page you are looking for was not found.","canonical":null,"meta":{"title":"404 error","description":"This page cannot be found","keywords":"","robots":"index"},"page_name":"pagenotfound","body_classes":{"lang-en":true,"lang-rtl":false,"country-IN":true,"currency-INR":true,"layout-full-width":true,"page-pagenotfound":true,"tax-display-enabled":true},"admin_notifications":[]},"shop":{"name":"Leffet","logo":"\/img\/leffet-logo-1635231017.jpg","stores_icon":"\/img\/logo_stores.png","favicon":"\/img\/favicon.ico"},"urls":{"base_url":"https:\/\/leffet.in\/","current_url":"https:\/\/leffet.in\/utsav\/jquery.js","shop_domain_url":"https:\/\/leffet.in","img_ps_url":"https:\/\/leffet.in\/img\/","img_cat_url":"https:\/\/leffet.in\/img\/c\/","img_lang_url":"https:\/\/leffet.in\/img\/l\/","img_prod_url":"https:\/\/leffet.in\/img\/p\/","img_manu_url":"https:\/\/leffet.in\/img\/m\/","img_sup_url":"https:\/\/leffet.in\/img\/su\/","img_ship_url":"https:\/\/leffet.in\/img\/s\/","img_store_url":"https:\/\/leffet.in\/img\/st\/","img_col_url":"https:\/\/leffet.in\/img\/co\/","img_url":"https:\/\/leffet.in\/themes\/leo_qos\/assets\/img\/","css_url":"https:\/\/leffet.in\/themes\/leo_qos\/assets\/css\/","js_url":"https:\/\/leffet.in\/themes\/leo_qos\/assets\/js\/","pic_url":"https:\/\/leffet.in\/upload\/","pages":{"address":"https:\/\/leffet.in\/address","addresses":"https:\/\/leffet.in\/addresses","authentication":"https:\/\/leffet.in\/login","cart":"https:\/\/leffet.in\/cart","category":"https:\/\/leffet.in\/index.php?controller=category","cms":"https:\/\/leffet.in\/index.php?controller=cms","contact":"https:\/\/leffet.in\/contact-us","discount":"https:\/\/leffet.in\/discount","guest_tracking":"https:\/\/leffet.in\/guest-tracking","history":"https:\/\/leffet.in\/order-history","identity":"https:\/\/leffet.in\/identity","index":"https:\/\/leffet.in\/","my_account":"https:\/\/leffet.in\/my-account","order_confirmation":"https:\/\/leffet.in\/order-confirmation","order_detail":"https:\/\/leffet.in\/index.php?controller=order-detail","order_follow":"https:\/\/leffet.in\/order-follow","order":"https:\/\/leffet.in\/order","order_return":"https:\/\/leffet.in\/index.php?controller=order-return","order_slip":"https:\/\/leffet.in\/credit-slip","pagenotfound":"https:\/\/leffet.in\/page-not-found","password":"https:\/\/leffet.in\/password-recovery","pdf_invoice":"https:\/\/leffet.in\/index.php?controller=pdf-invoice","pdf_order_return":"https:\/\/leffet.in\/index.php?controller=pdf-order-return","pdf_order_slip":"https:\/\/leffet.in\/index.php?controller=pdf-order-slip","prices_drop":"https:\/\/leffet.in\/prices-drop","product":"https:\/\/leffet.in\/index.php?controller=product","search":"https:\/\/leffet.in\/search","sitemap":"https:\/\/leffet.in\/sitemap","stores":"https:\/\/leffet.in\/stores","supplier":"https:\/\/leffet.in\/supplier","register":"https:\/\/leffet.in\/login?create_account=1","order_login":"https:\/\/leffet.in\/order?login=1"},"alternative_langs":{"en-us":"https:\/\/leffet.in\/page-not-found"},"theme_assets":"\/themes\/leo_qos\/assets\/","actions":{"logout":"https:\/\/leffet.in\/?mylogout="},"no_picture_image":{"bySize":{"small_default":{"url":"https:\/\/leffet.in\/img\/p\/en-default-small_default.jpg","width":98,"height":109},"cart_default":{"url":"https:\/\/leffet.in\/img\/p\/en-default-cart_default.jpg","width":135,"height":175},"medium_default":{"url":"https:\/\/leffet.in\/img\/p\/en-default-medium_default.jpg","width":239,"height":310},"home_default":{"url":"https:\/\/leffet.in\/img\/p\/en-default-home_default.jpg","width":430,"height":645},"large_default":{"url":"https:\/\/leffet.in\/img\/p\/en-default-large_default.jpg","width":2400,"height":3600}},"small":{"url":"https:\/\/leffet.in\/img\/p\/en-default-small_default.jpg","width":98,"height":109},"medium":{"url":"https:\/\/leffet.in\/img\/p\/en-default-medium_default.jpg","width":239,"height":310},"large":{"url":"https:\/\/leffet.in\/img\/p\/en-default-large_default.jpg","width":2400,"height":3600},"legend":""}},"configuration":{"display_taxes_label":true,"display_prices_tax_incl":true,"is_catalog":false,"show_prices":true,"opt_in":{"partner":false},"quantity_discount":{"type":"discount","label":"Discount"},"voucher_enabled":0,"return_enabled":0},"field_required":[],"breadcrumb":{"links":[{"title":"Home","url":"https:\/\/leffet.in\/"}],"count":1},"link":{"protocol_link":"https:\/\/","protocol_content":"https:\/\/"},"time":1635964073,"static_token":"b68a7b36e8930a00073a73a5e6feb04a","token":"1e349f1ad001a955c4ebab3a87a0ed6b"};
        var psemailsubscription_subscription = "https:\/\/leffet.in\/module\/ps_emailsubscription\/subscription";
        var psr_icon_color = "#F19D76";
        var review_error = "An error occurred while processing your request. Please try again";
        var show_popup = 1;
        var txt_not_found = "No products found";
        var type_dropdown_defaultcart = "dropdown";
        var type_flycart_effect = "fade";
        var width_cart_item = "265";
        var wishlist_add = "The product was successfully added to your wishlist";
        var wishlist_already = "The product already exists in your wishlist";
        var wishlist_cancel_txt = "Cancel";
        var wishlist_confirm_del_txt = "Delete selected item?";
        var wishlist_del_default_txt = "Cannot delete default wishlist";
        var wishlist_email_txt = "Email";
        var wishlist_loggin_required = "You must be logged in to manage your wishlist";
        var wishlist_ok_txt = "Ok";
        var wishlist_quantity_required = "You must enter a quantity";
        var wishlist_remove = "The product was successfully removed from your wishlist";
        var wishlist_reset_txt = "Reset";
        var wishlist_send_txt = "Send";
        var wishlist_send_wishlist_txt = "Send wishlist";
        var wishlist_url = "https:\/\/leffet.in\/module\/leofeature\/mywishlist";
        var wishlist_viewwishlist = "View your wishlist";
      </script>
<script type="text/javascript">
	var choosefile_text = "Choose file";
	var turnoff_popup_text = "Do not show this popup again";

	var size_item_quickview = 144;
	var style_scroll_quickview = 'horizontal';
	
	var size_item_page = 144;
	var style_scroll_page = 'horizontal';
	
	var size_item_quickview_attr = 144;	
	var style_scroll_quickview_attr = 'horizontal';
	
	var size_item_popup = 190;
	var style_scroll_popup = 'vertical';
</script>


  <script type="text/javascript">
	
	var FancyboxI18nClose = "Close";
	var FancyboxI18nNext = "Next";
	var FancyboxI18nPrev = "Previous";
	var current_link = "http://leffet.in/";		
	var currentURL = window.location;
	currentURL = String(currentURL);
	currentURL = currentURL.replace("https://","").replace("http://","").replace("www.","").replace( /#\w*/, "" );
	current_link = current_link.replace("https://","").replace("http://","").replace("www.","");
	var text_warning_select_txt = "Please select One to remove?";
	var text_confirm_remove_txt = "Are you sure to remove footer row?";
	var close_bt_txt = "Close";
	var list_menu = [];
	var list_menu_tmp = {};
	var list_tab = [];
	var isHomeMenu = 0;
	
</script>	<script type="text/javascript" src="/modules/facebookpsconnect/views/js/jquery-1.11.0.min.js"></script>
	<script type="text/javascript" src="/modules/facebookpsconnect/views/js/module.js"></script>


<script type="text/javascript">
	// instantiate object
	var fbpsc = fbpsc || new FpcModule('fbpsc');

	// get errors translation
		fbpsc.msgs = {"id":"You have not filled out the application ID","secret":"You have not filled out the application Secret","htmlElement":"You have not filled out the html element","positionName":"You have not filled out the name field","padding":"You have not filled out the padding element or this isn't an INTEGER","margin":"You have not filled out the margin element or this isn't an INTEGER","callback":"You have not filled out the application callback","scope":"You have not filled out the scope of App permissions","developerKey":"You have not filled out the developer Key","socialEmail":"You have not filled out your e-mail","delete":"Delete","prefixCode":"You have to set the prefix code","voucherAmount":"You have to set the voucher amount","voucherPercent":"You have to set the voucher percent","apiType":"You have to select a connection method","defaultText":"You have to fill out the default text"};
	
	
	// set URL of admin img
	fbpsc.sImgUrl = '/modules/facebookpsconnect/views/img/';

	// set URL of admin img
	fbpsc.sAdminImgUrl = '/img/admin/';

	// set URL of module's web service
		fbpsc.sWebService = '/modules/facebookpsconnect/ws-facebookpsconnect.php';
	

</script>
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="https://leffet.in/modules/baproductscarousel/views/js/assets/owl.carousel.js"></script>
<script>
	$(document).ready(function($) {
				if (auto_play == 'true') {
			setInterval(checktime_1,1500);
			function checktime_1() {
				if (!$('.template_slide:hover')) {
					if(!$('body').hasClass('modal-open')) {
						$('.fadeOut_1').trigger('play.owl.autoplay');
					}
					else {
						$('.fadeOut_1').trigger('stop.owl.autoplay');
					}
				}
			}
		}
		$('.fadeOut_1').owlCarousel({
			animateOut: 'slideOutDown',
			animateIn: 'flipInX',
			autoplayHoverPause:true,
			loop: false,
			autoplay:true,
			margin: 10,
			nav :true,
			dots :false,
			navText : ['<i class="fa fa-angle-left" aria-hidden="true"></i>','<i class="fa fa-angle-right" aria-hidden="true"></i>'],
			responsive:{
				0:{
					items:2,
					nav :true,
					dots :false,
				},
				600:{
					items:2,
					nav :true,
					dots :false,
				},
				1000:{
					items:3,
					nav :true,
					dots :false,
				}
			}
		});
			});
</script><link rel="stylesheet" href="/themes/_libraries/font-awesome/css/font-awesome.css" />
<script>
                 var id_customer_ba = '0';
                 var rtl = '0';
                </script><style type="text/css" media="screen">
			.fadeOut_1 > .owl-nav > .owl-prev, 
		.fadeOut_1 > .owl-nav > .owl-next {
			background: #FFFFFF !important;
			color: #222222 !important;
			font-size: 18px;
			margin-top: -30px;
			position: absolute;
			top: 42%;
			text-align: center;
			line-height: 39px;
			border:1px solid #fff;
			width: 40px;
			height: 40px;
		}
		.template_slide .fadeOut_1_title .page-title-categoryslider{
			color: #222222;
		}
		.template_slide .fadeOut_1_title .page-title-categoryslider:after{
			background-color: #222222;
		}
		.fadeOut_1 .owl-nav .owl-prev:hover, 
		.fadeOut_1 .owl-nav .owl-next:hover {
			background: #222222 !important;
		}
		.fadeOut_1 .whislist_casour{
			background: #FFFFFF;
			color:#222222;
			border: 1px solid #222222;
		}
		.fadeOut_1 .ad_info_pro h4 a:hover{
			color: #222222;
		}
		.fadeOut_1 .whislist_casour>a{
			background: transparent !important;
			color:#222222;
		}
		.fadeOut_1 .whislist_casour:hover,.compare_check,.compare_check a{
			background: #222222 !important;
			color: #FFFFFF !important;
			transition: all 0.4s ease-in-out 0s;
		}
		.fadeOut_1 .whislist_casour:hover a{
			color: #FFFFFF !important;
		}
		.fadeOut_1 .ad_info_pro h4 a{
			font-size: 13px;
			color: #FFFFFF;
		}
		.fadeOut_1 .add_to_carsou .ajax_add_to_cart_button:hover{
			color: #FFFFFF !important;
		}
		.fadeOut_1 .add_to_carsou .ajax_add_to_cart_button{
			background:#222222 !important;
			color: #FFFFFF;
		}
	</style>
<script type="text/javascript">
	(window.gaDevIds=window.gaDevIds||[]).push('d6YPbH');
	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

            ga('create', 'UA-211302207-1', 'auto');
                    ga('set', 'anonymizeIp', true);
                ga('send', 'pageview');
    
    ga('require', 'ec');
</script>

<!-- @file modules\appagebuilder\views\templates\hook\header -->

<script>
    /**
     * List functions will run when document.ready()
     */
    var ap_list_functions = [];
    /**
     * List functions will run when window.load()
     */
    var ap_list_functions_loaded = [];

    /**
     * List functions will run when document.ready() for theme
     */
    
    var products_list_functions = [];
</script>


<script type='text/javascript'>
    var leoOption = {
        category_qty:1,
        product_list_image:0,
        product_one_img:1,
        productCdown: 1,
        productColor: 0,
        homeWidth: 430,
        homeheight: 645,
	}

    ap_list_functions.push(function(){
        if (typeof $.LeoCustomAjax !== "undefined" && $.isFunction($.LeoCustomAjax)) {
            var leoCustomAjax = new $.LeoCustomAjax();
            leoCustomAjax.processAjax();
        }
    });
</script>




    
    
     <!-- Facebook tracking code -->

    <meta name="facebook-domain-verification" content="tua4rv0128nelcmxlq6c0imwm3a9yp" />
    
    
  </head>

  <body id="pagenotfound" class="lang-en country-in currency-inr layout-full-width page-pagenotfound tax-display-enabled fullwidth">

    
      
    

    <main id="page">
      
              
      <header id="header">
        <div class="header-container">
          
                <style>
    @media (min-width: 992px) {
    .header-top i {
        color: #000;
    }
    .box-header .right-header i {
        color: #000;
    }
    
    }
    </style>
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<div id="loader-common-dev" class="spinner-bg">
<div class="spinner-lazy">
<div class="double-bounce1"></div>
<div class="double-bounce2"></div>
</div>
</div>

  <div class="header-banner">
            <div class="inner"></div>
      </div>



  <nav class="header-nav">
    <div class="topnav">
              <div class="inner"></div>
          </div>
    <div class="bottomnav">
              <div class="inner"><!-- @file modules\appagebuilder\views\templates\hook\ApRow -->
<div class="wrapper"
>

<div class="container container-large">
    <div        class="row ApRow  has-bg bg-boxed"
                            style="background: no-repeat;"        data-bg_data=" no-repeat"        >
                                            <!-- @file modules\appagebuilder\views\templates\hook\ApColumn -->
<div    class="col-xl-3 col-lg-4 col-md-3 col-sm-5 col-xs-5 col-sp-5 hidden-sp ApColumn "
	    >
                    
    </div><!-- @file modules\appagebuilder\views\templates\hook\ApColumn -->
<div    class="col-xl-6 col-lg-4 col-md-6 col-sm-6 col-xs-6 col-sp-6 hidden-sm-down ApColumn "
	    >
                    
    </div><!-- @file modules\appagebuilder\views\templates\hook\ApColumn -->
<div    class="col-xl-3 col-lg-4 col-md-3 col-sm-7 col-xs-7 col-sp-12 nav-right ApColumn "
	    >
                    
    </div>            </div>
</div>
</div>
    </div>
          </div>
  </nav>



  <div class="header-top">
          <div class="inner"><!-- @file modules\appagebuilder\views\templates\hook\ApRow -->
<div class="wrapper"
>

<div class="container container-large">
    <div        class="row box-header ApRow  has-bg bg-boxed"
                            style="background: no-repeat;"        data-bg_data=" no-repeat"        >
                                            <!-- @file modules\appagebuilder\views\templates\hook\ApColumn -->
<div    class="col-xl-3 col-lg-2 col-md-6 col-sm-6 col-xs-12 col-sp-12 header-logo ApColumn "
	    >
                    <!-- @file modules\appagebuilder\views\templates\hook\ApImage -->
    <div id="image-form_304598259970642" class="block header_logo ApImageHotspot header_logo ApImageHotspot">
        
                                                <a href="https://leffet.in" >
            
            <div class="imagehotspot-container">
                <div style="position: relative; /* height: 0px; padding-bottom: 34%; padding-bottom: image's height divided by width multiply by 100 */">
                                        <img src="/themes/leo_qos/assets/img/modules/appagebuilder/images/black-logo.png" class=""
                            
                            title=""
                            alt=""
                            style=" width:auto; 
                            height:auto" />

                    
                                    </div>
            </div>




                        </a>
                    

                        </div>



    <script type="text/javascript">
        ap_list_functions.push(function(){
            //window.prettyPrint();

            $(".redhotspot").css({
                "background": "#cc0000",
                "border-radius": "19.2px"
            });

            function blink_hotspot() {
                // car image
                $('.redhotspot').animate({ "opacity": '0.3' }, 'slow')
                                .animate({ 'opacity': '0.8' }, 'fast', function () { blink_hotspot(); });
            }

            blink_hotspot();
        });


// Dien config vao day
// có config : image-left, image-right
        /*
        $("#fhotspot1").LiteTooltip({
            textalign: "left",
            trigger: "hover",   // click
            templatename: "BostonBlue",
            backcolor: '#ff0000',
            delay : '1000',
            title:
            '<div class="template">' +
            '<p style="padding: 15px; font-size: 11px; line-height: 20px;">' +
            '<img src="animal_1920_1080_1.jpg" class="image-right" style="max-width: 75px; width: 100%;" />' +
            'Take your pick of standard and available wheels on the 2013 Ford Fusion.' +
            '</p>' +
            '</div>'
        });

        $("#fhotspot2").LiteTooltip({
            location : "left-bottom",
            textalign: "center",
            trigger: "hover",
            templatename: "BostonBlue",
            debug : true,
            width : '500px',
            delay : '1000',
            opacity : '0.2',
            margin : '50px',
            padding: '10px',
            textcolor: '#ff0000',
            backcolor: '#ff0000',
            title:
            '<div class="template">' +
            '<p style="padding: 15px; font-size: 11px; line-height: 20px;">' +
            '<img src="animal_1920_1080_1.jpg" class="image-right" style="max-width: 75px; width: 100%;" />' +
            'Ambient lighting in the Titanium with cool interior illumination.' +
            '</p>' +
            '</div>'
        });


                location:   top | right | bottom | left | top-left | top-right | right-top | right-bottom |bottom-left | bottom-right | left-top | left-bottom
                title:          
                backcolor:      #ff0000
                textalign:      left, right, center
                trigger:        hoverable, hover, focus, click
                textcolor:      #ff0000
                opacity:
                templatename:
                width:
                margin:
                padding:
                delay:
                issticky: true, false
                container:
                shadow:
                debug:true
         */

    </script>

    </div><!-- @file modules\appagebuilder\views\templates\hook\ApColumn -->
<div    class="col-xl-6 col-lg-8 col-md-3 col-sm-3 col-xs-3 col-sp-3 center-header ApColumn "
	    >
                    <!-- @file modules\appagebuilder\views\templates\hook\ApSlideShow -->
<div id="memgamenu-form_5852801847688911" class="ApMegamenu">
			    
                <nav data-megamenu-id="5852801847688911" class="leo-megamenu cavas_menu navbar navbar-default disable-canvas " role="navigation">
                            <!-- Brand and toggle get grouped for better mobile display -->
                            <div class="navbar-header">
                                    <button type="button" class="navbar-toggler hidden-lg-up" data-toggle="collapse" data-target=".megamenu-off-canvas-5852801847688911">
                                            <span class="sr-only">Toggle navigation</span>
                                            &#9776;
                                            <!--
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                            -->
                                    </button>
                            </div>
                            <!-- Collect the nav links, forms, and other content for toggling -->
                                                        <div class="leo-top-menu collapse navbar-toggleable-md megamenu-off-canvas megamenu-off-canvas-5852801847688911"><ul class="nav navbar-nav megamenu horizontal">    <li data-menu-type="controller" class="nav-item  " >
        <a class="nav-link has-category" href="https://leffet.in/" target="_self">
                            
                            <span class="menu-title">Home</span>
                                                        </a>
    </li>
    <li data-menu-type="cms" class="nav-item icon-new " >
        <a class="nav-link has-category" href="https://leffet.in/content/4-about-us" target="_self">
                            
                            <span class="menu-title">About Us</span>
                                                        </a>
    </li>
<li data-menu-type="url" class="parent-sub-menu nav-item parent dropdown   " >
    <!--<a id="drop-open25"  class="nav-link dropdown-toggle has-category" data-toggle="dropdown"  href="https://leffet.in/#"  target="_self"  aria-haspopup="true" aria-expanded="false">-->
        <a id="drop-open25" data-toggle="dropdown" class="nav-link dropdown-toggle has-category most-sub-menu" href="javascript:void(0)" target="_self" >

                    
                    <span class="menu-title">Collections</span>
                                		<b class="caret"></b>
    </a>	
    
        <div aria-labelledby="drop-open25" class="dropdown-menu level1"  >
        <div class="dropdown-menu-inner">
            <div class="row">
                <div class="col-sm-12 mega-col" data-colwidth="12" data-type="menu" >
                    <div class="inner">
                        <ul>
                                                            <li data-menu-type="category" class="nav-item   " >
            <a class="nav-link" href="https://leffet.in/17-üzvi">
            
                            <span class="menu-title">Üzvi</span>
                                    
                    </a>

    </li>
            
                                                            <li data-menu-type="category" class="nav-item   " >
            <a class="nav-link" href="https://leffet.in/15-pariza">
            
                            <span class="menu-title">Pariza </span>
                                    
                    </a>

    </li>
            
                                                            <li data-menu-type="category" class="nav-item   " >
            <a class="nav-link" href="https://leffet.in/16-ikattra">
            
                            <span class="menu-title">Ikattra </span>
                                    
                    </a>

    </li>
            
                                                            <li data-menu-type="category" class="nav-item   " >
            <a class="nav-link" href="https://leffet.in/19-utsav">
            
                            <span class="menu-title">Utsav</span>
                                    
                    </a>

    </li>
            
                                                            <li data-menu-type="category" class="nav-item   " >
            <a class="nav-link" href="https://leffet.in/2-all-collections">
            
                            <span class="menu-title">All</span>
                                    
                    </a>

    </li>
            
                                                    </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

</li>
<script>
    $(document).ready(function () {
    $('.most-sub-menu').attr('data-toggle',"dropdown");
    $('.most-sub-menu').dropdown();

     /**   $(document).on("click",".most-sub-menu",function() {
            $(this).attr('data-toggle',"dropdown");
            $(this).dropdown();
        
    });**/

    });
</script>    <li data-menu-type="category" class="nav-item  " >
        <a class="nav-link has-category" href="https://leffet.in/18-most-loved" target="_top">
                            
                            <span class="menu-title">Most Loved</span>
                                                        </a>
    </li>
</ul></div>
            </nav>
            <script type="text/javascript">
            // <![CDATA[				
                            // var type="horizontal";
                            // checkActiveLink();
                            // checkTarget();
                            list_menu_tmp.id = '5852801847688911';
                            list_menu_tmp.type = 'horizontal';
            // ]]>
            
                                
                                    // var show_cavas = 0;
                                    list_menu_tmp.show_cavas =0;	
                    
                                
                    list_menu_tmp.list_tab = list_tab;
                    list_menu.push(list_menu_tmp);
                    list_menu_tmp = {};	
                    list_tab = {};
                    
            </script>
    
	</div>

    </div><!-- @file modules\appagebuilder\views\templates\hook\ApColumn -->
<div    class="col-xl-3 col-lg-2 col-md-3 col-sm-3 col-xs-9 col-sp-9 right-header ApColumn "
	    >
                    <!-- @file modules\appagebuilder\views\templates\hook\ApModule -->


<!-- Block search module -->
<div id="leo_search_block_top" class="block exclusive">
	<h4 class="title_block"><i class="icomoon icon-search"></i></h4>
	<form method="get" action="https://leffet.in/index.php?controller=productsearch" id="leosearchtopbox">
		<input type="hidden" name="fc" value="module" />
		<input type="hidden" name="module" value="leoproductsearch" />
		<input type="hidden" name="controller" value="productsearch" />
                <input type="hidden" name="leoproductsearch_static_token" value="b68a7b36e8930a00073a73a5e6feb04a"/>
		    	<label>Search products:</label>
		<div class="block_content clearfix leoproductsearch-content">		
			<div class="list-cate-wrapper" style="display: none">
				<input id="leosearchtop-cate-id" name="cate" value="" type="hidden">
				<a href="javascript:void(0)" id="dropdownListCateTop" class="select-title" rel="nofollow" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					<span>All Categories</span>
					<i class="material-icons pull-xs-right">keyboard_arrow_down</i>
				</a>
				<div class="list-cate dropdown-menu" aria-labelledby="dropdownListCateTop">
					<a href="#" data-cate-id="" data-cate-name="All Categories" class="cate-item active" >All Categories</a>				
					<a href="#" data-cate-id="2" data-cate-name="All Collections" class="cate-item cate-level-1" >All Collections</a>
					
  <a href="#" data-cate-id="12" data-cate-name="Dresses" class="cate-item cate-level-2" >--Dresses</a>
  <a href="#" data-cate-id="10" data-cate-name="Casuals" class="cate-item cate-level-3" >---Casuals</a>
  <a href="#" data-cate-id="11" data-cate-name="Formals" class="cate-item cate-level-3" >---Formals</a>
  <a href="#" data-cate-id="17" data-cate-name="Üzvi" class="cate-item cate-level-3" >---Üzvi</a>
  <a href="#" data-cate-id="15" data-cate-name="Pariza" class="cate-item cate-level-3" >---Pariza</a>
  <a href="#" data-cate-id="16" data-cate-name="Ikattra" class="cate-item cate-level-3" >---Ikattra</a>
  <a href="#" data-cate-id="19" data-cate-name="Utsav" class="cate-item cate-level-3" >---Utsav</a>
  <a href="#" data-cate-id="18" data-cate-name="Most Loved" class="cate-item cate-level-2" >--Most Loved</a>
  
				</div>
			</div>
			<div class="leoproductsearch-result">
				<div class="leoproductsearch-loading cssload-speeding-wheel"></div>
				<input class="search_query form-control grey" type="text" id="leo_search_query_top" name="search_query" value="" placeholder="Search"/>
			</div>
			<button type="submit" id="leo_search_top_button" class="btn btn-default button button-small"><i class="icomoon icon-search "></i></button> 
		</div>
	</form>
</div>
<script type="text/javascript">
	var blocksearch_type = 'top';
</script>
<!-- /Block search module -->
<!-- @file modules\appagebuilder\views\templates\hook\ApModule -->
<div class="userinfo-selector popup-over pull-right e-scale">
 <a href="javascript:void(0)" data-toggle="dropdown" class="popup-title" title="Account">
    <i class="icomoon icon-user"></i>
    <span class="user_title hidden-xl-down">My Account</span>
 </a>
  <ul class="popup-content dropdown-menu user-info">
        <!--
      <li>
        <a
          class="signin leo-quicklogin"
          data-enable-sociallogin="enable"
          data-type="popup"
          data-layout="login"
          href="javascript:void(0)"
          title="Log in to your customer account"
          rel="nofollow"
        >
        <i class="fa fa-unlock-alt"></i>
          <span>Sign in</span>
        </a>
      </li>-->
      <li>
        <a
          class="signin leo-quicklogin"
          href="https://leffet.in/my-account"
          title="Log in to your customer account"
          rel="nofollow"
        >
        <i class="fa fa-unlock-alt"></i>
          <span>Sign in</span>
        </a>
      </li>
        <li class="hidden-lg-up">
      <a
        class="myacount dropdown-item"
        href="https://leffet.in/my-account"
        title="My account"
        rel="nofollow"
      >
      <i class="fa fa-user"></i>
        <span>My account</span>
      </a>
    </li>
    <li class="hidden-lg-up">
      <a
        class="checkout dropdown-item"
        href="//leffet.in/cart?action=show"
        title="Checkout"
        rel="nofollow"
      >
      <i class="fa fa-sign-out" aria-hidden="true"></i>
        <span>Checkout</span>
      </a>
    </li>
            </ul>
</div><!-- @file modules\appagebuilder\views\templates\hook\ApGenCode -->

	    <a class="ap-btn-wishlist ap-wishlist" href="//leffet.in/module/leofeature/mywishlist" title="Wishlist" rel="nofollow">      <i class="icomoon icon-wishlist"></i>      <span class="ap-total-wishlist ap-total"></span>    </a>    
<!-- @file modules\appagebuilder\views\templates\hook\ApModule -->
<div id="cart-block">
  <div class="blockcart cart-preview inactive" data-refresh-url="//leffet.in/module/ps_shoppingcart/ajax">
    <div class="header">
              <i class="icomoon icon-cart"></i>
        <div class="cart-quantity">
          <span class="cart-products-count">0</span>
        </div>
          </div>
  </div>
</div>
    </div>            </div>
</div>
</div>
    <div class="bootstrap">
	</div></div>
          </div>
  

<script>
    function startMainLoader () {

$(".dor-page-loading").css("display", "block");
// $("#main-loader").addClass("loading");
}

function stopMainLoader () {
if( $("#main-loader").length ) {
}
$("#main-loader").removeClass("loading");
$(".dor-page-loading").css("display", "none");
}
</script>




          
        </div>
      </header>
      
        
<aside id="notifications">
  <div class="container">
    
    
    
      </div>
</aside>
      
      <section id="wrapper">
       
        <nav data-depth="1" class="breadcrumb hidden-sm-down">
  <div class="container container-large">
    <ol itemscope itemtype="http://schema.org/BreadcrumbList">
      
                  
            <li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
              <a itemprop="item" href="https://leffet.in/">
                <span itemprop="name">Home</span>
              </a>
              <meta itemprop="position" content="1">
            </li>
          
              
    </ol>
  </div>
</nav>      
      

              
              <div class="container  ">
                
          <div class="row">
            

            
  <div id="content-wrapper" class="col-lg-12 col-xs-12">
    
    

  <section id="main">

      
    
      
        <header class="page-header">
          <h1>
  The page you are looking for was not found.
</h1>
        </header>
      
    

    
  <section id="content" class="page-content page-not-found">
  
    <img class="img-not-found img-fluid" src="https://leffet.in/themes/leo_qos/assets/img/404.png" alt="Sorry for the inconvenience." />
    <h4>Sorry for the inconvenience.</h4>
    <p>Search again what you are looking for</p>

    
      <!-- Block search module TOP -->
<div id="search_widget" class="search-widget popup-over" data-search-controller-url="//leffet.in/search">
	<a id="click_show_search" href="javascript:void(0)" data-toggle="dropdown" class="float-xs-right popup-title">
	    <i class="icon-Icon_Search"></i>
	</a>
	<form method="get" action="//leffet.in/search" class="form-search" id="search_form">
		<input type="hidden" name="controller" value="search">
		<input class="search_query ui-autocomplete-input" type="text" name="s" value="" placeholder="Search our catalog" aria-label="Search">
		<button class="search-button" type="submit">
			<i class="icomoon icon-search"></i>
		</button>
	</form>
</div>
<!-- /Block search module TOP -->

    

    
      
    

  
</section>

  
    
      <footer class="page-footer">
        
          <!-- Footer content -->
        
      </footer>
    

  </section>


    
  </div>


            
          </div>
                  </div>
              	
      </section>

      <footer id="footer" class="footer-container">
        
          
  <div class="footer-top">
          <div class="inner"><!-- @file modules\appagebuilder\views\templates\hook\ApRow -->
<div class="wrapper"
>

<div class="container">
    <div        class="row section-footer ApRow  has-bg bg-boxed"
                            style="background: no-repeat;"        data-bg_data=" no-repeat"        >
                                            <!-- @file modules\appagebuilder\views\templates\hook\ApColumn -->
<div    class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-xs-12 col-sp-12  ApColumn "
	    >
                    <!-- @file modules\appagebuilder\views\templates\hook\ApBlockLink -->
            <div class="block ApLink ApBlockLink">
                        
                            <ul>
                                                            <li><a href="https://leffet.in/contact-us" target="_self">Contact Us</a></li>
                                                                                <li><a href="https://leffet.in/content/4-about-us" target="_self">About Us</a></li>
                                                                                <li><a href="https://leffet.in/content/6-privacy-policy" target="_self">Privacy Policy</a></li>
                                                    </ul>
                    </div>
    
    </div><!-- @file modules\appagebuilder\views\templates\hook\ApColumn -->
<div    class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-xs-12 col-sp-12  ApColumn "
	    >
                    <!-- @file modules\appagebuilder\views\templates\hook\ApBlockLink -->
            <div class="block ApLink ApBlockLink">
                        
                            <ul>
                                                            <li><a href="https://leffet.in/content/8-leffet-s-art-elements" target="_self">Leffet&#039;s Art Elements</a></li>
                                                                                <li><a href="https://leffet.in/content/11-size-chart" target="_self">Size Chart</a></li>
                                                                                <li><a href="https://leffet.in/content/3-terms-and-conditions" target="_self">Terms &amp; Conditions</a></li>
                                                                                <li><a href="https://leffet.in/content/7-shipping-refund-policy" target="_self">Shipping &amp; Refund Policy</a></li>
                                                    </ul>
                    </div>
    
    </div><!-- @file modules\appagebuilder\views\templates\hook\ApColumn -->
<div    class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-xs-12 col-sp-12 section-social ApColumn "
	    >
                    <!-- @file modules\appagebuilder\views\templates\hook\ApModule -->

  <div class="block-social block links accordion_small_screen">
  	<p class="h4 title_block hidden-sm-down">Follow Us On Social</p>
  	<div class="title clearfix hidden-md-up" data-target="#footer_block_social" data-toggle="collapse">
	    <span class="h4 title_block">Follow Us On Social</span>
	    <span class="float-xs-right">
	      <span class="navbar-toggler collapse-icons">
	        <i class="material-icons add">&#xE313;</i>
	        <i class="material-icons remove">&#xE316;</i>
	      </span>
	    </span>
	</div>
    <ul class="collapse" id="footer_block_social">
              <li class="facebook"><a href="https://www.facebook.com/leffetpret" title="Facebook" target="_blank"><span>Facebook</span></a></li>
              <li class="twitter"><a href="https://twitter.com/leffetbysm" title="Twitter" target="_blank"><span>Twitter</span></a></li>
              <li class="youtube"><a href="https://www.youtube.com/channel/UCNT648_JaIf1K2Ad1DkzRLQ/featured" title="YouTube" target="_blank"><span>YouTube</span></a></li>
              <li class="pinterest"><a href="https://in.pinterest.com/leffetbysanjevmarwaaha" title="Pinterest" target="_blank"><span>Pinterest</span></a></li>
              <li class="instagram"><a href="https://www.instagram.com/leffet_pret/" title="Instagram" target="_blank"><span>Instagram</span></a></li>
          </ul>
  </div>


    </div><!-- @file modules\appagebuilder\views\templates\hook\ApColumn -->
<div    class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-xs-12 col-sp-12  ApColumn "
	    >
                    <!-- @file modules\appagebuilder\views\templates\hook\ApGeneral -->
<div     class="block copyright p-0 ApRawHtml">
	                    © 2021 leffet.in. All rights reserved    	</div><!-- @file modules\appagebuilder\views\templates\hook\ApGeneral -->
<div     class="block card-row ApRawHtml">
	                    <i class="fab fa-cc-visa fa-2x fa-fw" ></i><i class="fab fa-cc-mastercard fa-2x fa-fw"></i><i class="fab fa-cc-amex fa-2x fa-fw"></i><i class="fab fa-cc-amazon-pay fa-2x fa-fw"></i>    	</div>
    </div>            </div>
</div>
</div>
    </div>
      </div>


  <div class="footer-center">
          <div class="inner"><!-- @file modules\appagebuilder\views\templates\hook\ApRow -->
<div class="wrapper"
>

<div class="container">
    <div        class="row ApRow  has-bg bg-boxed"
                            style="background: no-repeat;"        data-bg_data=" no-repeat"        >
                                            <!-- @file modules\appagebuilder\views\templates\hook\ApColumn -->
<div    class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 col-sp-12  ApColumn "
	    >
                    
    </div>            </div>
</div>
</div>
    <div class="bootstrap">
	</div>

<style type="text/css">
            </style>
<script>
    var lcpWidgetInterval;
    var closePopupTimeout;
    var lzWidgetInterval;
    var paldeskInterval;
    var hubspotInterval;
    var arcuOptions;
        var arcItems = [];
        window.addEventListener('load', function(){
        jQuery('#arcontactus').remove();
        var $arcuWidget = jQuery('<div>', {
            id: 'arcontactus'
        });
        jQuery('body').append($arcuWidget);
                    arCuClosedCookie = arCuGetCookie('arcu-closed');
                jQuery('#arcontactus').on('arcontactus.init', function(){
            jQuery('#arcontactus').addClass('arcuAnimated').addClass('slideInRight');
            setTimeout(function(){
                jQuery('#arcontactus').removeClass('slideInRight');
            }, 1000);
            var $key = $('<input>', {
                type: 'hidden',
                name: 'key',
                value: '67VY6KW9'
            });
            jQuery('#arcontactus .callback-countdown-block-phone form').append($key);
                    });
                                                var arcItem = {
            };
                            arcItem.id = 'msg-item-2';
                                    arcItem.class = 'msg-item-whatsapp ';
            arcItem.title = "Chat with us";                         arcItem.icon = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"></path></svg>';
            arcItem.noContainer = 1;
            arcItem.href = 'https://wa.me/919167860709';
            arcItem.target = '_blank';
            arcItem.color = '#1ebea5';
                        arcItems.push(arcItem);
                arcuOptions = {
            drag: true,
            mode: 'regular',
            align: 'right',
            reCaptcha: false,
            reCaptchaKey: '',
            countdown: 0,
            theme: '#008749',
                                                buttonIcon: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"></path></svg>',
                                                                    showHeaderCloseBtn: true,
                                        headerCloseBtnBgColor: '#008749',
                                        buttonText: false,
                        itemsIconType: 'non-rounded',
            buttonSize: 'medium',
            buttonIconSize: 24,
            menuSize: 'small',
            phonePlaceholder: "+XXX-XX-XXX-XX-XX",
            callbackSubmitText: "Waiting for call",
            errorMessage: "Connection error. Please refresh the page and try again.",
            callProcessText: "We are calling you to phone",
            callSuccessText: "Thank you.<br />We are call you back soon.",
            iconsAnimationSpeed: 800,
            iconsAnimationPause: 2000,
            callbackFormText: "Please enter your phone number<br /> and we call you back soon",
            items: arcItems,
            ajaxUrl: 'https://leffet.in/module/arcontactus/ajax',                             promptPosition: 'top',
                                                            popupAnimation: 'fadeinup',
                                style: '',
                                    callbackFormFields: {
                                                phone: {
                    name: 'phone',
                    enabled: true,
                    required: true,
                    type: 'tel',
                    label: '',
                    placeholder: "+XXX-XX-XXX-XX-XX"
                },
                            },
        };
        jQuery('#arcontactus').contactUs(arcuOptions);
                                            });
                                                                        </script>



</div>
      </div>


  <div class="footer-bottom">
          <div class="inner"></div>
      </div>

<!-- Global site tag (gtag.js) - Google Analytics -->
        
                            <div id="back-top"><a href="#" class="fa fa-angle-double-up"></a></div>
              </footer>

    </main>

    
        <script type="text/javascript" src="https://leffet.in/themes/core.js" ></script>
  <script type="text/javascript" src="https://leffet.in/themes/leo_qos/assets/js/theme.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/ps_emailsubscription/views/js/ps_emailsubscription.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/blockreassurance/views/js/front.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/leoslideshow/views/js/iView/raphael-min.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/leoslideshow/views/js/iView/iview.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/leoslideshow/views/js/leoslideshow.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/leoquicklogin/views/js/leoquicklogin.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/leofeature/views/js/leofeature_cart.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/leofeature/views/js/jquery.mousewheel.min.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/leofeature/views/js/jquery.mCustomScrollbar.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/leofeature/views/js/jquery.rating.pack.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/leofeature/views/js/leofeature_review.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/leofeature/views/js/leofeature_wishlist.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/facebookpsconnect/views/js/module.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/arcontactus/views/js/jquery.contactus.min.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/arcontactus/views/js/scripts.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/baproductscarousel/views/js/slidebutton.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/baproductscarousel/views/js/assets/owl.carousel.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/g_testimonial/views/js/front/testimonial.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/ps_googleanalytics/views/js/GoogleAnalyticActionLib.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/appagebuilder/views/js/countdown.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/boninstagramslick/views/js/slick.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/boninstagramslick//views/js/slick-front.js" ></script>
  <script type="text/javascript" src="https://leffet.in/js/jquery/ui/jquery-ui.min.js" ></script>
  <script type="text/javascript" src="https://leffet.in/js/jquery/plugins/fancybox/jquery.fancybox.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/ps_searchbar/ps_searchbar.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/leobootstrapmenu/views/js/leobootstrapmenu.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/ps_shoppingcart/ps_shoppingcart.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/blockgrouptop/views/js/blockgrouptop.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/leoproductsearch/views/js/jquery.autocomplete_productsearch.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/leoproductsearch/views/js/leosearch.js" ></script>
  <script type="text/javascript" src="https://leffet.in/themes/leo_qos/assets/js/custom.js" ></script>
  <script type="text/javascript" src="https://leffet.in/themes/leo_qos/assets/js/jquery.bpopup.min.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/appagebuilder/views/js/waypoints.min.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/appagebuilder/views/js/instafeed.min.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/appagebuilder/views/js/jquery.stellar.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/appagebuilder/views/js/owl.carousel.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/appagebuilder/views/js/imagesloaded.pkgd.min.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/appagebuilder/views/js/slick.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/appagebuilder/views/js/jquery.elevatezoom.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/appagebuilder/views/js/ApImageHotspot.js" ></script>
  <script type="text/javascript" src="https://leffet.in/modules/appagebuilder/views/js/script.js" ></script>


<script type="text/javascript">
	var choosefile_text = "Choose file";
	var turnoff_popup_text = "Do not show this popup again";

	var size_item_quickview = 144;
	var style_scroll_quickview = 'horizontal';
	
	var size_item_page = 144;
	var style_scroll_page = 'horizontal';
	
	var size_item_quickview_attr = 144;	
	var style_scroll_quickview_attr = 'horizontal';
	
	var size_item_popup = 190;
	var style_scroll_popup = 'vertical';
</script>    

    
      <div class="modal leo-quicklogin-modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="leo-quicklogin-form row">
			<ul class="lql-action lql-inactive">
			<li class="lql-action-bt">
				<p class="lql-bt lql-bt-login">Login</p>
			</li>
			<li class="lql-action-bt">
				<p class="lql-bt lql-bt-register">Register</p>
			</li>
		</ul>
		<div class="leo-form leo-login-form col-sm-6 leo-form-active">
		<h3 class="leo-login-title">			
			<span class="title-both">
				Existing Account Login
			</span>
		
			<span class="title-only">
				Login to your account
			</span>		
		</h3>
		<form class="lql-form-content leo-login-form-content" action="#" method="post">
			<div class="form-group lql-form-mesg has-success">					
			</div>			
			<div class="form-group lql-form-mesg has-danger">					
			</div>
			<div class="form-group lql-form-content-element">
				<input type="email" class="form-control lql-email-login" name="lql-email-login" required="" placeholder="Email Address">
			</div>
			<div class="form-group lql-form-content-element">
				<input type="password" class="form-control lql-pass-login" name="lql-pass-login" required="" placeholder="Password">
			</div>
			<div class="form-group row lql-form-content-element">				
				<div class="col-xs-6">
											<input type="checkbox" class="lql-rememberme" name="lql-rememberme">
						<label class="form-control-label"><span>Remember Me</span></label>
									</div>				
				<div class="col-xs-6 text-sm-right">
					<a role="button" href="#" class="leoquicklogin-forgotpass">Forgot Password ?</a>
				</div>
			</div>
			<div class="form-group text-right">
				<button type="submit" class="form-control-submit lql-form-bt lql-login-bt btn btn-primary">			
					<span class="leoquicklogin-loading leoquicklogin-cssload-speeding-wheel"></span>
					<i class="leoquicklogin-icon leoquicklogin-success-icon material-icons">&#xE876;</i>
					<i class="leoquicklogin-icon leoquicklogin-fail-icon material-icons">&#xE033;</i>
					<span class="lql-bt-txt">					
						Login
					</span>
				</button>
			</div>
			<div class="form-group lql-callregister">
				<a role="button" href="#" class="lql-callregister-action">No account? Create one here ?</a>
			</div>
		</form>
		<div class="leo-resetpass-form">
			<h3>Reset Password</h3>
			<form class="lql-form-content leo-resetpass-form-content" action="#" method="post">
				<div class="form-group lql-form-mesg has-success">					
				</div>			
				<div class="form-group lql-form-mesg has-danger">					
				</div>
				<div class="form-group lql-form-content-element">
					<input type="email" class="form-control lql-email-reset" name="lql-email-reset" required="" placeholder="Email Address">
				</div>
				<div class="form-group">					
					<button type="submit" class="form-control-submit lql-form-bt leoquicklogin-reset-pass-bt btn btn-primary">			
						<span class="leoquicklogin-loading leoquicklogin-cssload-speeding-wheel"></span>
						<i class="leoquicklogin-icon leoquicklogin-success-icon material-icons">&#xE876;</i>
						<i class="leoquicklogin-icon leoquicklogin-fail-icon material-icons">&#xE033;</i>
						<span class="lql-bt-txt">					
							Reset Password
						</span>
					</button>
				</div>
				
			</form>
		</div>
	</div>
	
	<div class="leo-form leo-register-form col-sm-6 leo-form-active">
		<h3 class="leo-register-title">
			New Account Register
		</h3>
		<form class="lql-form-content leo-register-form-content" action="#" method="post">
			<div class="form-group lql-form-mesg has-success">					
			</div>			
			<div class="form-group lql-form-mesg has-danger">					
			</div>
			<div class="form-group lql-form-content-element">
				<input type="text" class="form-control lql-register-firstname" name="lql-register-firstname"  placeholder="First Name">
			</div>
			<div class="form-group lql-form-content-element">
				<input type="text" class="form-control lql-register-lastname" name="lql-register-lastname" required="" placeholder="Last Name">
			</div>
			<div class="form-group lql-form-content-element">
				<input type="email" class="form-control lql-register-email" name="lql-register-email" required="" placeholder="Email Address">
			</div>
			<div class="form-group lql-form-content-element">
				<input type="password" class="form-control lql-register-pass" name="lql-register-pass" required="" placeholder="Password">
			</div>
						<div class="form-group text-right">				
				<button type="submit" name="submit" class="form-control-submit lql-form-bt lql-register-bt btn btn-primary">			
					<span class="leoquicklogin-loading leoquicklogin-cssload-speeding-wheel"></span>
					<i class="leoquicklogin-icon leoquicklogin-success-icon material-icons">&#xE876;</i>
					<i class="leoquicklogin-icon leoquicklogin-fail-icon material-icons">&#xE033;</i>
					<span class="lql-bt-txt">					
						Create an Account
					</span>
				</button>
			</div>
			<div class="form-group lql-calllogin">
				<div>Already have an account?</div>
				<a role="button" href="#" class="lql-calllogin-action">Log in instead</a>
				Or
				<a role="button" href="#" class="lql-calllogin-action lql-callreset-action">Reset password</a>
			</div>
		</form>
	</div>
</div>

            </div> 
            <div class="modal-footer"></div>
        </div>
    </div>
</div><div class="leoquicklogin-mask"></div>

<div class="leoquicklogin-slidebar">
    <div class="leoquicklogin-slidebar-wrapper">
        <div class="leoquicklogin-slidebar-top">
            <button type="button" class="leoquicklogin-slidebar-close btn btn-secondary">
                <i class="material-icons">&#xE5CD;</i>
                <span>Close</span>
            </button>
        </div>
        <div class="leo-quicklogin-form row">
			<ul class="lql-action lql-inactive">
			<li class="lql-action-bt">
				<p class="lql-bt lql-bt-login">Login</p>
			</li>
			<li class="lql-action-bt">
				<p class="lql-bt lql-bt-register">Register</p>
			</li>
		</ul>
		<div class="leo-form leo-login-form col-sm-6 leo-form-active">
		<h3 class="leo-login-title">			
			<span class="title-both">
				Existing Account Login
			</span>
		
			<span class="title-only">
				Login to your account
			</span>		
		</h3>
		<form class="lql-form-content leo-login-form-content" action="#" method="post">
			<div class="form-group lql-form-mesg has-success">					
			</div>			
			<div class="form-group lql-form-mesg has-danger">					
			</div>
			<div class="form-group lql-form-content-element">
				<input type="email" class="form-control lql-email-login" name="lql-email-login" required="" placeholder="Email Address">
			</div>
			<div class="form-group lql-form-content-element">
				<input type="password" class="form-control lql-pass-login" name="lql-pass-login" required="" placeholder="Password">
			</div>
			<div class="form-group row lql-form-content-element">				
				<div class="col-xs-6">
											<input type="checkbox" class="lql-rememberme" name="lql-rememberme">
						<label class="form-control-label"><span>Remember Me</span></label>
									</div>				
				<div class="col-xs-6 text-sm-right">
					<a role="button" href="#" class="leoquicklogin-forgotpass">Forgot Password ?</a>
				</div>
			</div>
			<div class="form-group text-right">
				<button type="submit" class="form-control-submit lql-form-bt lql-login-bt btn btn-primary">			
					<span class="leoquicklogin-loading leoquicklogin-cssload-speeding-wheel"></span>
					<i class="leoquicklogin-icon leoquicklogin-success-icon material-icons">&#xE876;</i>
					<i class="leoquicklogin-icon leoquicklogin-fail-icon material-icons">&#xE033;</i>
					<span class="lql-bt-txt">					
						Login
					</span>
				</button>
			</div>
			<div class="form-group lql-callregister">
				<a role="button" href="#" class="lql-callregister-action">No account? Create one here ?</a>
			</div>
		</form>
		<div class="leo-resetpass-form">
			<h3>Reset Password</h3>
			<form class="lql-form-content leo-resetpass-form-content" action="#" method="post">
				<div class="form-group lql-form-mesg has-success">					
				</div>			
				<div class="form-group lql-form-mesg has-danger">					
				</div>
				<div class="form-group lql-form-content-element">
					<input type="email" class="form-control lql-email-reset" name="lql-email-reset" required="" placeholder="Email Address">
				</div>
				<div class="form-group">					
					<button type="submit" class="form-control-submit lql-form-bt leoquicklogin-reset-pass-bt btn btn-primary">			
						<span class="leoquicklogin-loading leoquicklogin-cssload-speeding-wheel"></span>
						<i class="leoquicklogin-icon leoquicklogin-success-icon material-icons">&#xE876;</i>
						<i class="leoquicklogin-icon leoquicklogin-fail-icon material-icons">&#xE033;</i>
						<span class="lql-bt-txt">					
							Reset Password
						</span>
					</button>
				</div>
				
			</form>
		</div>
	</div>
	
	<div class="leo-form leo-register-form col-sm-6 leo-form-active">
		<h3 class="leo-register-title">
			New Account Register
		</h3>
		<form class="lql-form-content leo-register-form-content" action="#" method="post">
			<div class="form-group lql-form-mesg has-success">					
			</div>			
			<div class="form-group lql-form-mesg has-danger">					
			</div>
			<div class="form-group lql-form-content-element">
				<input type="text" class="form-control lql-register-firstname" name="lql-register-firstname"  placeholder="First Name">
			</div>
			<div class="form-group lql-form-content-element">
				<input type="text" class="form-control lql-register-lastname" name="lql-register-lastname" required="" placeholder="Last Name">
			</div>
			<div class="form-group lql-form-content-element">
				<input type="email" class="form-control lql-register-email" name="lql-register-email" required="" placeholder="Email Address">
			</div>
			<div class="form-group lql-form-content-element">
				<input type="password" class="form-control lql-register-pass" name="lql-register-pass" required="" placeholder="Password">
			</div>
						<div class="form-group text-right">				
				<button type="submit" name="submit" class="form-control-submit lql-form-bt lql-register-bt btn btn-primary">			
					<span class="leoquicklogin-loading leoquicklogin-cssload-speeding-wheel"></span>
					<i class="leoquicklogin-icon leoquicklogin-success-icon material-icons">&#xE876;</i>
					<i class="leoquicklogin-icon leoquicklogin-fail-icon material-icons">&#xE033;</i>
					<span class="lql-bt-txt">					
						Create an Account
					</span>
				</button>
			</div>
			<div class="form-group lql-calllogin">
				<div>Already have an account?</div>
				<a role="button" href="#" class="lql-calllogin-action">Log in instead</a>
				Or
				<a role="button" href="#" class="lql-calllogin-action lql-callreset-action">Reset password</a>
			</div>
		</form>
	</div>
</div>

        <div class="leoquicklogin-slidebar-bottom">
            <button type="button" class="leoquicklogin-slidebar-close btn btn-secondary">
                <i class="material-icons">&#xE5CD;</i>
                <span>Close</span>
            </button>
        </div>
    </div>
</div>
<div data-type="dropup" style="position: fixed; bottom:20px; left:20px" class="leo-fly-cart solo type-fixed enable-dropdown">
	<div class="leo-fly-cart-icon-wrapper">
		<a href="javascript:void(0)" class="leo-fly-cart-icon" data-type="dropup"><i class="material-icons">&#xE8CC;</i></a>
		<span class="leo-fly-cart-total"></span>
	</div>
		<div class="leo-fly-cart-cssload-loader"></div>
</div>
    
  </body>
</html>